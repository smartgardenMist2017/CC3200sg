
// Driverlib includes
#include "cameradriver.h"
#include "rom.h"
#include "rom_map.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "hw_types.h"
#include "hw_ints.h"
#include "uart.h"
#include "interrupt.h"
#include "pinmux.h"
#include "utils.h"
#include "prcm.h"
#include "pin.h"

// Common interface include
#include "uart_if.h"

//Common c header files
#include "stdint.h"
//#include "stdio.h"
#include "stdlib.h"




#define APPLICATION_VERSION  	"1.1.1"
#define APP_NAME             	"UART Echo"
#define CAMERA 				 	UARTA1_BASE
#define CAMERA_PERIPH  			PRCM_UARTA1
#define Uart1GetChar()        	MAP_UARTCharGet(CAMERA)
#define Uart1PutChar(c)       	MAP_UARTCharPut(CAMERA,c)
#define Uart1CharsAvail()		MAP_UARTCharsAvail(CAMERA)
#define BAUD_RATE				115200
#define MAX_STRING_LENGTH    	80




const uint8_t sync_command[] = {0xAA, 0x0D, 0x00, 0x00 ,0x00 ,0x00}; //(AA 0D 00 00 00 00)
const uint8_t sync_ack[] = {0xAA, 0x0E, 0x0D, 0x00, 0x00, 0x00}; // (AA 0E 0D xx 00 00)

const uint8_t init_command[] = {0xAA, 0x01, 0x00, 0x07, 0x03, 0x03}; //(AA 01 00 07 03 03)
const uint8_t init_ack[] = {0xAA, 0x0E, 0x01, 0x00, 0x00 ,0x00};//(AA 0E 01 xx 00 00)

const uint8_t packagesize_command[] = {0xAA, 0x06, 0x08, 0x00, 0x02, 0x00}; //(AA 06 08 00 02 00)
const uint8_t packagesize_ack[] = {0xAA, 0x0E, 0x06, 0x00, 0x00, 0x00};//(AA 0E 06 xx 00 00)

const uint8_t snapshot_command[] = {0xAA, 0x05, 0x00, 0x00, 0x00, 0x00};//(AA 05 01 00 00 00)
const uint8_t snapshot_ack[] = {0xAA, 0x0E, 0x05, 0x00, 0x00, 0x00};//(AA 0E 05 xx 00 00)

const uint8_t getpicture[] = {0xAA, 0x04, 0x05, 0x00, 0x00, 0x00};//(AA 04 01 00 00 00)
const uint8_t getpicture_ack_data[] = {0xAA, 0x0E, 0x04, 0x00, 0x00, 0x00, 0xAA, 0x0A, 0x05, 0x01, 0x01, 0x01};// (AA 0E 04 xx 00 00) (AA 0A 01 ~~ ~~ ~~)

volatile uint8_t ack_send[] = {0xAA, 0x0E, 0x00, 0x00, 0x00, 0x00}; //(AA 0E 00 00 00 00)

volatile uint8_t ACK[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
volatile uint8_t ACK_DATA[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00,0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
volatile uint8_t package[518];
//volatile uint8_t jpeg[6000];

#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif

static void
Board_init(void)
{
/* In case of TI-RTOS vector table is initialize by OS itself */
#ifndef USE_TIRTOS
  //
  // Set vector table base
  //
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    //
    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}

static void
UART_init(void)
{

	 MAP_PRCMPeripheralClkEnable(PRCM_UARTA1, PRCM_RUN_MODE_CLK);
	 MAP_PinTypeUART(PIN_07, PIN_MODE_5);
	 MAP_PinTypeUART(PIN_08, PIN_MODE_5);
	 MAP_UARTConfigSetExpClk(CAMERA, MAP_PRCMPeripheralClockGet(CAMERA_PERIPH),
	                   BAUD_RATE, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
	                    UART_CONFIG_PAR_NONE));
}

static void
CLEAR_ACK(void)
{
	int i;
	for(i = 0; i < sizeof(ACK)-1; i++)
	{
		ACK[i] = 0x00;
	}
}


static int
CAMERA_COMAND(const uint8_t *commandptr, const uint8_t *ackptr)
{
int i;
int i_stop = 0;
int STOP = 0;
int watchdog = 0;
	for(i= 0; i < 6; i++)
	{
		Uart1PutChar(*commandptr);
		commandptr++;
	}
	i = 0;

	while(i < 6 & watchdog < 50000)
	{
	if(Uart1CharsAvail())
	{
		ACK[i] = Uart1GetChar();
		i++;
	}
	watchdog++;
	}

	i_stop = i;
	if(i >= 5)
	i = 0;

	for(i = 0; i < 6; i++)
	{
		if(ACK[i] == *ackptr)
		{
			STOP++;
		}
		ackptr++;
	}
    STOP = STOP >= 5 ? 1 : 0;

return STOP;
}


// returns size of image taken
static int
GET_PICTURE(void)
{
int i;
int i_stop = 0;
int STOP = 0;
int watchdog = 0;
	for(i= 0; i < 6; i++)
	{
		Uart1PutChar(getpicture[i]);
	}
	i = 0;

	while(i < 12 & watchdog < 100000)
	{
	if(Uart1CharsAvail())
	{
		ACK_DATA[i] = Uart1GetChar();
		i++;
	}
	watchdog++;
	}

	i_stop = i;
	if(i >= 11)
	i = 0;

	for(i = 0; i < 12; i++)
	{
		if(ACK_DATA[i] == getpicture_ack_data[i])
		{
			STOP++;
		}
	}
    STOP = STOP >= 6 ? 1 : 0;

return STOP;
}

static int
GET_PACKAGE(int packsize)
{
int i;
int i_stop = 0;
int STOP = 0;
int watchdog = 0;
	for(i= 0; i < 6; i++)
	{
		Uart1PutChar(ack_send[i]);
	}
	i = 0;


	while(i < packsize)
	{
	if(Uart1CharsAvail())
	{
		package[i] = Uart1GetChar();
		i++;
	}
	}

return STOP;
}




void take_picture(char *jpegptr)
{
int retval = 0;
int i = 0;
int jpegindex;
uint16_t  last_package;
uint16_t image_size;
uint16_t loop_count;
uint16_t j;
Board_init();
UART_init();

// Sync Camera
while(retval == 0){
retval = CAMERA_COMAND(&sync_command[0], &sync_ack[0]);
UtilsDelay(10);
}

CLEAR_ACK();
retval = 0;

// initailize camera to recieve an image resolutions of 160x128
while(retval == 0){
retval = CAMERA_COMAND(&init_command[0], &init_ack[0]);
UtilsDelay(10);
}

CLEAR_ACK();
retval = 0;

// tell camera to take a snapshot
while(retval == 0){
retval = CAMERA_COMAND(&packagesize_command[0], &packagesize_ack[0]);
UtilsDelay(10);
}

CLEAR_ACK();
//retval = 0;
//
//// tell camera to take a snapshot
//while(retval == 0){
//retval = CAMERA_COMAND(&snapshot_command[0], &snapshot_ack[0]);
//UtilsDelay(10);
//}

retval = 0;

while(retval == 0){
for(i = 0; i < 2; i++){
retval = GET_PICTURE();
UtilsDelay(10);
}
}

jpegindex = 0;
GET_PACKAGE(518);
ack_send[4]++;

image_size = ((0x0F & package[4])*16*16) + ((0xF0 & package[4] >> 4)*16*16*16) + package[3];
last_package = image_size % 506;
loop_count = image_size/506 - 1;


for(i = 10; i < 516; i++ )
{
	*jpegptr = package[i];
	jpegptr++;
}

retval = 0;

for(i = 0; i < loop_count; i++){
GET_PACKAGE(512);
ack_send[4]++;
for(j= 4; j < 510; j++)
{
	*jpegptr = package[j];
	jpegptr++;
}
}

GET_PACKAGE(last_package + 6);
for(j= 4; j < last_package + 4; j++)
{
	*jpegptr = package[j];
	jpegptr++;
}


UtilsDelay(10);

}
