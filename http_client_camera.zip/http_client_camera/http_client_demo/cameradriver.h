#ifndef __CAMERADRIVER_H__
#define __CAMERADRIVER_H__

extern void take_picture(char *jpegptr);

#endif 
